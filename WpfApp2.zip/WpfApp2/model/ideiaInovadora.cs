﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp2.persistencia;

namespace WpfApp2.model
{
    internal class ideiaInovadora
    {
        public string Area { get; set; } = "";
        public string Idea { get; set; } = "";

        public float Custo { get; set; } = 0;

        public Boolean CadastrarIdeiaInovadora(ideiaInovadora i)
        {
            BD.SalvarBD(i);

            return true;

        }
    }
}
