﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using WpfApp2.model;

namespace WpfApp2.control
{
    internal class ideiaInovadoraControle
    {
        private ideiaInovadora ModeloPersistencia = new();
        public Boolean ControleCadastrarideiaInovadora(string area, string ideia, float custo)
        {
            ideia = ideia + "!!!!";
            
        ideiaInovadora ii = new()
        {
            Area = area,
            Ideia = ideia,
            Custo = custo
        };

            if (ModeloPersistencia.CadastrarIdeiaInovadora(ii))
                return true;
            return true;
        }

    }
}
