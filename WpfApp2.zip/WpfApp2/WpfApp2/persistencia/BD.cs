﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp2.model;

namespace WpfApp2.persistencia
{
    internal class BD
    {
        public static List<ideiaInovadora> mybd = new();

        public static void SalvarBD(ideiaInovadora i) => mybd.Add(i);

        public static List<ideiaInovadora> RetomarBD() => mybd;
    }
}
